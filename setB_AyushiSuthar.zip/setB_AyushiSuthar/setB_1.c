#include <stdio.h>
#include <string.h>
 
char* removeAdjDup(char* str, int n)
{
  
    if (n == 0) {
        return str;
    }
 
    
    int i, k = 0;
    int len = strlen(str);
 
    
    for (i = 1; i < len; i++)
    {
        
        if (str[i - 1] != str[i]) {
            str[k++] = str[i - 1];
        }
        else {
        
            while (i < len && str[i - 1] == str[i]) {
                i++;
            }
        }
    }
    str[k++] = str[i - 1];
    str[k] = '\0';
 
    if (k != n) {
        return removeAdjDup(str, k);    
    }
       else{
        printf("Empty String\n");}
 
    return str;
}
 
int main(void)
{
    char str[] = "DBAABDABBA";
    int n = strlen(str);
 
    printf("%s\n",removeAdjDup(str, n));
 
    return 0;
}
